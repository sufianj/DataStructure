#include "GraphEdge.h"

GraphEdge::GraphEdge (void) {
    src = dst = NULL;
    length = 0;
    next = rev = NULL;
}

GraphEdge::GraphEdge (const GraphNode* src, const GraphNode* dst, const double length, const GraphEdge* pt) {
    this->src = src;
    this->dst = dst;
    this->length = length;
    this->rev = NULL;
    this->next = pt;
}

const GraphNode* GraphEdge::getSrc (void) const {
    return src;
}

const GraphNode* GraphEdge::getDst (void) const {
    return dst;
}

const double GraphEdge::getLength (void) const {
    return length;
}

const GraphEdge* GraphEdge::getRev (void) const {
    return rev;
}

const GraphEdge* GraphEdge::getNext (void) const {
    return next;
}

void GraphEdge::setSrc (const GraphNode* src) {
    this->src = src;
}

void GraphEdge::setDst (const GraphNode* dst) {
    this->dst = dst;
}

void GraphEdge::setLength (const double length) {
    this->length = length;
}

void GraphEdge::setRev (const GraphEdge* obj) {
    rev = obj;
}

bool GraphEdge::operator < (GraphEdge obj) {
    return this->length < obj.getLength();
}

bool GraphEdge::operator > (GraphEdge obj) {
    return this->length > obj.getLength();
}

ostream& operator << (ostream& opt, GraphEdge obj) {
    opt << "[ " << obj.src->getName() << " -> " 
        << obj.dst->getName() << ", " 
        << setiosflags(ios::fixed) << setprecision(2) 
        << obj.length << " ]";
    return opt;
}