/*
**      Graph - Storage & Algorithms
**
**      Include following algorithms:
**          1.Graph Traversal: Depth First Search
**          2.Graph Traversal: Breadth First Search
**          3.Minimal Spanning Tree: Prim
**          4.Minimal Spanning Tree: Kruskal
**          5.SSSP: Dijkstra
**          6.ASSP: Floyd
**
**      Program by Anchi Bao
**      2010/12/15
*/

#ifndef ANCHI_GRAPH_H
#define ANCHI_GRAPH_H

#include "GraphNode.h"
#include "GraphEdge.h"

#include "CommonResource.h"

class Graph {
public:
    Graph (void);
    Graph (const int, const int);

    void addNode (const string);
    void addEdge (const string, const string, const double len);

    const GraphNode* findNode (const string) const;
    const GraphEdge* findEdge (const GraphNode*, const GraphNode*) const;

    void BFS (const GraphNode*, ostream&);
    void DFS (const GraphNode*, ostream&);

    void Prim (const GraphNode*, ostream&);
    void Kruskal (const GraphNode*, ostream&);

    void Dijkstra (const GraphNode*, ostream&);
    void Floyd (ostream&);

    void RouteDisp (const int, const int, ostream&);

private:
    int NodeCnt,            //  �Ѽ��붥����
        EdgeCnt,            //  �Ѽ������
        NodeSize,           //  ��������
        EdgeSize;           //  ������
    bool *Mark;             //  ���ʱ��
    int **Via;              //  �м���¼
    double **Distance;      //  ���·��
    GraphNode *NodeSet;     //  �㼯
    GraphNode *NodeBuff;    //  �㼯ͷָ��
    GraphEdge *EdgeSet;     //  �߼�
    GraphEdge *EdgeBuff;    //  �߼�ͷָ��
    GraphEdge *MSTEdge;     //  ��С�������߼�
    GraphEdge **VtEdge;     //  ���������
};

#endif