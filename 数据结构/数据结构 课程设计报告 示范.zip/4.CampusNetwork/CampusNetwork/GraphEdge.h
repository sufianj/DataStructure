/*
**      Graph Edge
**
**      Program by Anchi Bao
**      2010/12/15
*/

#ifndef ANCHI_GRAPH_EDGE
#define ANCHI_GRAPH_EDGE

#include <iostream> 

#include "GraphNode.h"

using namespace std;

class GraphEdge {
public:
    GraphEdge (void);
    GraphEdge (const GraphNode*, const GraphNode*, const double, const GraphEdge*);

    void* operator new (size_t, void* p) { return p; }

    const GraphNode* getSrc (void) const;
    const GraphNode* getDst (void) const;
    const double getLength (void) const;
    const GraphEdge* getRev (void) const;
    const GraphEdge* getNext (void) const;

    void setSrc (const GraphNode*);
    void setDst (const GraphNode*);
    void setLength (const double);
    void setRev (const GraphEdge*);

    bool operator < (GraphEdge obj);
    bool operator > (GraphEdge obj);
    friend ostream& operator << (ostream &opt, GraphEdge obj);

private:
    const GraphNode *src, 
                    *dst;
    const GraphEdge *next,
                    *rev;
    double length;
};

#endif