#include "DisjointSet.h"

DisjointSet::DisjointSet (void) {
    father = 0;
}

DisjointSet::DisjointSet (const int size) {
    father = new int [size+7];
    for (int i=1; i<=size; i++)
        father[i] = i;
}

const int DisjointSet::find (const int index) {
    if (father[index] == index)
        return index;
    return father[index] = find(father[index]);
}

void DisjointSet::joint (const int x, const int y) {
    father[find(x)] = father[find(y)];
}
