#ifndef ANCHI_COORDS_H
#define ANCHI_COORDS_H

#include "CommonResource.h"

class Coord {
public:
    Coord (void);
    Coord (double, double);

    const double getX (void) const;
    const double getY (void) const;

    void setX (const double);
    void setY (const double);
    void setCoord (const double, const double);

private:
    double xpos, 
           ypos;
};

#endif