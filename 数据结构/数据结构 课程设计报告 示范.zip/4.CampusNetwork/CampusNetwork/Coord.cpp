#include "Coord.h"

Coord::Coord (void) {
    xpos = ypos = 0.00;
}

Coord::Coord (const double x, const double y) {
    xpos = x;
    ypos = y;
}

const double Coord::getX (void) const {
    return xpos;
}

const double Coord::getY (void) const {
    return ypos;
}

void Coord::setX (const double x) {
    xpos = x;
}

void Coord::setY (const double y) {
    ypos = y;
}

void Coord::setCoord (const double x, const double y) {
    xpos = x;
    ypos = y;
}