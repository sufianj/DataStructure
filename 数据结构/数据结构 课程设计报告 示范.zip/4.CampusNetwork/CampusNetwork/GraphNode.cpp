/*
**      Graph Node
**
**      Program by Anchi Bao
**      2010/12/15
*/

#include "GraphNode.h"

GraphNode::GraphNode (void) {
    name = "Default Name";
    index = 0;
}

GraphNode::GraphNode (const string name, const int index) {
    this->name = name;
    this->index = index;
}

const string GraphNode::getName (void) const {
    return name;
}

const int GraphNode::getIndex (void) const {
    return index;
}

void GraphNode::setName (const string name) {
    this->name = name;
}

void GraphNode::setIndex (const int index) {
    this->index = index;
}

ostream& operator << (ostream& opt, GraphNode obj) {
    opt << "[" 
        << setw(2) << setfill('0') << obj.index 
        << "] " 
        << obj.name;
    return opt;
}