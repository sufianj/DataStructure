/*
**      Campus Network - Graph Algorithms
**      
**      Include following algorithms:
**          1.Graph Traversal: Depth First Search
**          2.Graph Traversal: Breadth First Search
**          3.Minimal Spanning Tree: Prim
**          4.Minimal Spanning Tree: Kruskal
**          5.SSSP: Dijkstra
**          6.ASSP: Floyd
**
**
**      Program by Anchi Bao
**      2010/12/30
*/


#include "CommonResource.h"
#include "Graph.h"

int main () {

    freopen("output.txt", "w", stdout);

    ifstream ipf("campus.txt");
    int N, E;

    string src, dst;
    double length;
    int i;

    ipf >> N >> E;

    Graph G(N, E);
    
    for (i=1; i<=N; i++) {
        ipf >> src;
        G.addNode(src);
    }
    
    cout << endl << endl;
    system("pause");

    cout << endl << endl;
    for (i=1; i<=E; i++) {
        ipf >> src >> dst >> length;
        G.addEdge(src, dst, length);
    }
    
    cout << endl << endl;
    system("pause");
    
    G.DFS(G.findNode("һ��"), cout);
    system("pause");

    G.BFS(G.findNode("һ��"), cout);
    system("pause");
    
    G.Prim(G.findNode("һ��"), cout);
    system("pause");

    G.Kruskal(G.findNode("һ��"), cout);
    system("pause");
    
    G.Dijkstra(G.findNode("��԰"), cout);
    system("pause");

    G.Floyd(cout);
    system("pause");

    return 0;
}