#include "Graph.h"

Graph::Graph (void) {
    NodeCnt = EdgeCnt = 0;
    Distance = NULL;
    NodeSet = NULL;
    NodeBuff = NULL;
    EdgeSet = NULL;
    EdgeBuff = NULL;
    MSTEdge = NULL;
    VtEdge = NULL;
    Mark = NULL;
    Via = NULL;
}

Graph::Graph (const int NodeSize, const int EdgeSize) {
    this->NodeSize = NodeSize;
    this->EdgeSize = EdgeSize;

    NodeCnt = EdgeCnt = 0;

    NodeSet = new GraphNode [NodeSize+7];
    NodeBuff = NodeSet;
    EdgeSet = new GraphEdge [EdgeSize*2+7];
    EdgeBuff = EdgeSet;

    int i, j;
    Distance = new double* [NodeSize+7];
    for (i=0; i<NodeSize+7; i++)
        Distance[i] = new double [NodeSize+7];
    for (i=0; i<NodeSize+7; i++)
        for (j=0; j<NodeSize+7; j++)
            Distance[i][j] = INF;

    Via = new int* [NodeSize+7];
    for (i=0; i<NodeSize+7; i++)
        Via[i] = new int [NodeSize+7];
    for (i=0; i<NodeSize+7; i++)
        for (j=0; j<NodeSize+7; j++)
            Via[i][j] = i;

    MSTEdge = new GraphEdge [NodeSize+7];
    
    VtEdge = new GraphEdge* [NodeSize+7];
    for (i=0; i<NodeSize+7; i++)
        VtEdge[i] = NULL;

    Mark = new bool [NodeSize+7];
}

void Graph::addNode (const string name) {
    if (findNode(name) != NULL)
        return;
    NodeCnt++;
    GraphNode *obj = new ((void*) ++NodeBuff) GraphNode(name, NodeCnt);
    cout << "Node Created. " << *NodeBuff << endl;
}

void Graph::addEdge (const string srcName, const string dstName, const double len) {
    addNode(srcName);
    addNode(dstName);
    if (findEdge(findNode(srcName), findNode(dstName)) != NULL)
        return;

    int isrc = findNode(srcName) ->getIndex();
    int idst = findNode(dstName) ->getIndex();

    EdgeCnt++;
    GraphEdge *cur = VtEdge[isrc] = new ((void*) ++EdgeBuff) GraphEdge(NodeSet+isrc, NodeSet+idst, len, VtEdge[isrc]);
    EdgeCnt++;
    GraphEdge *rev = VtEdge[idst] = new ((void*) ++EdgeBuff) GraphEdge(NodeSet+idst, NodeSet+isrc, len, VtEdge[idst]);

    cur->setRev(rev);
    rev->setRev(cur);
    cout << "Edge Created. " << *(EdgeBuff-1) << " " << *EdgeBuff << endl;
}

const GraphNode* Graph::findNode (const string name) const {
    for (int i=1; i<=NodeCnt; i++)
        if (NodeSet[i].getName() == name)
            return NodeSet+i;
    return NULL;
}

const GraphEdge* Graph::findEdge (const GraphNode* src, const GraphNode* dst) const {
    const GraphEdge* edge;
    for (edge=VtEdge[src->getIndex()]; edge!=NULL; edge=edge->getNext())
        if (edge->getDst() == dst)
            return edge;
    return NULL;
}

void Graph::BFS (const GraphNode* src, ostream& opt) {
    for (int i=1; i<=NodeCnt; i++)
        Mark[i] = false;
    Queue<const GraphNode*> Q;
    const GraphNode* curr = findNode(src->getName());
    const GraphNode* next;
    const GraphEdge* edge;
    Q.push(curr);
    Mark[curr->getIndex()] = true;
    while (!Q.empty()) {
        curr = Q.pop();
        opt << *curr << endl;
        for (edge=VtEdge[curr->getIndex()]; edge!=NULL; edge=edge->getNext()) {
            next = edge->getDst();
            if (Mark[next->getIndex()]) continue;
            Mark[next->getIndex()] = true;
            Q.push(next);
        }
    }
    opt << endl;
}

void Graph::DFS (const GraphNode* src, ostream& opt) {
    for (int i=1; i<=NodeCnt; i++)
        Mark[i] = false;
    Stack<const GraphNode*> S;
    const GraphNode* curr = findNode(src->getName());
    const GraphNode* next;
    const GraphEdge* edge;
    S.push(curr);
    Mark[curr->getIndex()] = true;
    while (!S.empty()) {
        curr = S.pop();
        opt << *curr << endl;
        for (edge=VtEdge[curr->getIndex()]; edge!=NULL; edge=edge->getNext()) {
            next = edge->getDst();
            if (Mark[next->getIndex()]) continue;
            Mark[next->getIndex()] = true;
            S.push(next);
        }
    }
    opt << endl;
}

void Graph::Prim (const GraphNode* src, ostream& opt) {
    for (int i=1; i<=NodeCnt; i++)
        Mark[i] = false;
    const GraphNode* cur = findNode(src->getName());
    const GraphEdge *edge;
    int isrc = cur->getIndex();
    int i, j;
    double min, tot=0.0;

    for (i=1; i<=NodeCnt; i++)
        Distance[isrc][i] = INF;
    for (edge=VtEdge[isrc]; edge!=NULL; edge=edge->getNext())
        Distance[isrc][edge->getDst()->getIndex()] = edge->getLength();
    Distance[isrc][isrc] = 0;

    for (i=1; i<=NodeCnt; i++)
        Via[isrc][i] = isrc;

    Mark[isrc] = true;

    for (i=1; i<=NodeCnt; i++) {
        min = INF;
        cur = NULL;
        for (j=1; j<=NodeCnt; j++) {
            if (Mark[j]) continue;
            if (Distance[isrc][j] >= min) continue;
            cur = &NodeSet[j];
            min = Distance[isrc][j];
        }
        if (cur == NULL) break;
        Mark[cur->getIndex()] = true;
        MSTEdge[i] = *findEdge(&NodeSet[ Via[isrc][cur->getIndex()] ], cur);
        tot += MSTEdge[i].getLength();
        for (edge=VtEdge[cur->getIndex()]; edge!=NULL; edge=edge->getNext()) {
            j = edge->getDst()->getIndex();
            if (Distance[isrc][j] <= edge->getLength()) continue;
            Distance[isrc][j] = edge->getLength();
            Via[isrc][j] = cur->getIndex();
        }
    }
    opt << endl << endl 
        << "Minimal Spanning Tree - Prim" << endl;
    opt << "Total Cost: "
        << setiosflags(ios::fixed) << setprecision(2) << tot << endl;
    for (i=1; i<NodeCnt; i++)
        opt << MSTEdge[i] << endl;
    opt << endl;
}

void Graph::Kruskal (const GraphNode* src, ostream& opt) {
    GraphEdge *Data = new GraphEdge [EdgeCnt];
    memcpy(Data, EdgeSet+1, sizeof(GraphEdge)*EdgeCnt);
    QuickSort<GraphEdge>::sort(Data, Data+EdgeCnt);

    DisjointSet Djs(NodeCnt);

    GraphEdge *edge = Data;
    int i, isrc, idst;
    double tot=0.0;
    for (i=1; i<NodeCnt; i++) {
        while (true) {
            isrc = edge->getSrc()->getIndex();
            idst = edge->getDst()->getIndex();
            if (Djs.find(isrc) == Djs.find(idst)) {
                edge++;
                continue;
            }
            MSTEdge[i] = *edge;
            tot += edge->getLength();
            Djs.joint(isrc, idst);
            break;
        }
    }
    opt << endl << endl 
        << "Minimal Spanning Tree - Kruskal" << endl;
    opt << "Total Cost: "
        << setiosflags(ios::fixed) << setprecision(2) << tot << endl;
    for (i=1; i<NodeCnt; i++)
        opt << MSTEdge[i] << endl;
    opt << endl;
}

void Graph::Dijkstra (const GraphNode* src, ostream& opt) {
    for (int i=1; i<=NodeCnt; i++)
        Mark[i] = false;
    const GraphNode* cur = findNode(src->getName());
    const GraphEdge *edge;
    int isrc = cur->getIndex();
    int i, j;
    double min;

    for (i=1; i<=NodeCnt; i++)
        Distance[isrc][i] = INF;
    for (edge=VtEdge[isrc]; edge!=NULL; edge=edge->getNext())
        Distance[isrc][edge->getDst()->getIndex()] = edge->getLength();
    Distance[isrc][isrc] = 0;

    for (i=0; i<NodeSize+7; i++)
        for (j=0; j<NodeSize+7; j++)
            Via[i][j] = i;

    Mark[isrc] = true;

    for (i=1; i<=NodeCnt; i++) {
        min = INF;
        cur = NULL;
        for (j=1; j<=NodeCnt; j++) {
            if (Mark[j]) continue;
            if (Distance[isrc][j] >= min) continue;
            cur = &NodeSet[j];
            min = Distance[isrc][j];
        }
        if (cur == NULL) break;
        Mark[cur->getIndex()] = true;
        for (edge=VtEdge[cur->getIndex()]; edge!=NULL; edge=edge->getNext()) {
            j = edge->getDst()->getIndex();
            if (Distance[isrc][j] <= min+edge->getLength()) continue;
            Distance[isrc][j] = min+edge->getLength();
            Via[isrc][j] = cur->getIndex();
        }
    }

    opt << endl << endl 
        << "SSSP - Dijkstra" << endl
        << "Source: " << *src << endl << endl;
    for (i=1; i<=NodeCnt; i++) {
        if (i==isrc)
            continue;
        opt << *src << " to " << NodeSet[i] << ": " 
            << setiosflags(ios::fixed) << setprecision(2) << Distance[isrc][i] << endl;
        opt << *src;
        RouteDisp(isrc, i, opt);
        cout << endl << endl;
    }
    opt << endl;
}

void Graph::Floyd (ostream& opt) {
    int i, j, k;
    const GraphEdge *edge;
    for (i=1; i<=NodeCnt; i++) {
        Distance[i][i] = 0;
        for (j=i+1; j<=NodeCnt; j++)
            Distance[i][j] = Distance[j][i] = INF;
        for (edge=VtEdge[i]; edge!=NULL; edge=edge->getNext())
            Distance[i][edge->getDst()->getIndex()] = edge->getLength();
    }
    for (i=1; i<=NodeCnt; i++)
        for (j=1; j<=NodeCnt; j++)
            Via[i][j] = i;

    for (k=1; k<=NodeCnt; k++)
        for (i=1; i<=NodeCnt; i++)
            for (j=1; j<=NodeCnt; j++)
                if (Distance[i][j] > Distance[i][k] + Distance[k][j]) {
                    Distance[i][j] = Distance[i][k] + Distance[k][j];
                    Via[i][j] = k;
                }

    opt << endl << endl 
        << "ASSP - Floyd" << endl << endl;
    for (i=1; i<NodeCnt; i++) {
        for (j=i+1; j<=NodeCnt; j++) {
            opt << NodeSet[i] << " to " << NodeSet[j] << ": " 
                << setiosflags(ios::fixed) << setprecision(2) << Distance[i][j] << endl;
            opt << NodeSet[i];
            RouteDisp(i, j, opt);
            cout << endl << endl;
        }
        cout << endl;
        system("pause");
        cout << endl << endl;
    }
    opt << endl;
}

void Graph::RouteDisp (const int isrc, const int idst, ostream& opt) {
    if (Via[isrc][idst] == isrc) {
        opt << " -> " << NodeSet[idst];
        return;
    }
    RouteDisp(isrc, Via[isrc][idst], opt);
    RouteDisp(Via[isrc][idst], idst, opt);
}