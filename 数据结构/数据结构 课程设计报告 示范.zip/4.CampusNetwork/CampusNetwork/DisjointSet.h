/*
**      Disjoint Set - O(1)
**
**      Program by Anchi Bao
**      2010/12/15
*/

#ifndef ANCHI_DISJOINT_SET_H
#define ANCHI_DISJOINT_SET_H

class DisjointSet {
public:
    DisjointSet (void);
    DisjointSet (const int);

    const int find (const int);
    void joint (const int, const int);

private:
    int *father;
};

#endif