#ifndef ANCHI_GRAPH_NODE_H
#define ANCHI_GRAPH_NODE_H

#include <iostream>

#include "CommonResource.h"

using namespace std;

class GraphNode
{
public:
    GraphNode (void);
    GraphNode (const string, const int);

    void* operator new (size_t, void* p) { return p; }

    const string getName (void) const;
    const int getIndex (void) const;

    void setName (const string);
    void setIndex (const int);

    friend ostream& operator << (ostream &opt, GraphNode obj);

private:
    string name;
    int index;
};

#endif