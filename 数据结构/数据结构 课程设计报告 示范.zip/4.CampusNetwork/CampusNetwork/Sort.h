/*
**      A Base Class for Sort Methods
**      includes function sort() and swap()
**
**      Usage:
**              #include "Sort.h"
**              ...
**              template <typename T>
**              class mySort : public Sort {
**              ...
**              };
**
**      Program by Anchi Bao
**      2010/12/14
*/

#ifndef ANCHI_SORT_H
#define ANCHI_SORT_H

#include "CommonResource.h"

template <typename T>
class Sort {
public:
    static void sort (T* head, T* back);
protected:
    static void swap (T *a, T* b);
};

template <typename T>
void Sort<T>::sort (T* head, T* back){
    //  This function should be overloaded in derived classes.
}

template <typename T>
void Sort<T>::swap (T *a, T *b) {
    T t = *a;
    *a = *b;
    *b = t;
}

#endif