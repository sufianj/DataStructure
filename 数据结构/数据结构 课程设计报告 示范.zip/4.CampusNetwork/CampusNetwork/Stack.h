/*
**      FIFO - Stack
**
**      Usage:
**          #include "Stack.h"
**          ...
**          Stack<int> Q;
**          ...
**          Q.push(100);
**          ...
**          int val = Q.get(),
**              tmp = Q.pop();
**
**      Program by Anchi Bao
**      2010/12/15
*/

#ifndef ANCHI_STACK_H
#define ANCHI_STACK_H

#define INIT_SIZE 100

#include <memory>

using namespace std;

template <typename T>
class Stack {
public:
    Stack (void);

    bool empty (void);
    
    void push (const T);
    const T pop (void);
    const T get (void);

private:
    T *data,
      *base,
      *top;
    int size;
};

template <typename T>
Stack<T>::Stack (void) {
    data = new T [INIT_SIZE];
    base = data;
    top = data;
    size = INIT_SIZE;
}

template <typename T>
bool Stack<T>::empty (void) {
    return top - base == 0;
}

template <typename T>
void Stack<T>::push (const T obj) {
    if (top-base == size) {
        data = new T [size + INIT_SIZE];
        memcpy(data, base, sizeof(T)*size);
        base = data;
        top = base + size;
        size = size + INIT_SIZE;
    }
    *(++top) = obj;
}

template <typename T>
const T Stack<T>::pop (void) {
    --size;
    return *(top--);
}

template <typename T>
const T Stack<T>::get (void) {
    return *top;
}

#undef INIT_SIZE

#endif