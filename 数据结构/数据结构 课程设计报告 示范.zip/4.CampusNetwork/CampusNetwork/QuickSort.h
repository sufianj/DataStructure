/*
**      Improved Quick Sort - O(n*logn)
**      When sorting range [head...back), use (FirstValue + LastValue + 2*MidValue)/4 to be the pivot for reference.
**
**      Usage:
**              #include "QuickSort.h"
**              ...
**              int * Data = new int[N];
**              ...
**              QuickSort<int>::sort(Data, Data+N);
**
**      Program by Anchi Bao
**      2010/12/14
*/

#ifndef ANCHI_QUICK_SORT_H
#define ANCHI_QUICK_SORT_H

#include "Sort.h"

template <typename T>
class QuickSort : public Sort<T> {
public:
    static void sort (T* head, T* back);
};

template <typename T>
void QuickSort<T>::sort (T* head, T* back){
    int size = back-head;
    if (size <= 1) return;

    T *i = head-1,
      *j = back,
      *m = head+(size>>1)-1;
    T pv = *m;
    while (i < j) {
        do i++; while (*i < pv);
        do j--; while (*j > pv);
        if (i < j) swap(i, j);
    }
    sort(head, j+1);
    sort(j+1, back);
}

#endif