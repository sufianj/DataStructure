/*
**      Binary Heap Sort - O(n*logn)
**      Sorts range [head...back)
**
**      The Heap used in this sorting method is improved that contains no "swap" operation, so it's even faster than QuickSort.
**
**      Usage:
**              #include "HeapSort.h"
**              ...
**              int * Data = new int[N];
**              ...
**              HeapSort<int>::sort(Data, Data+N);
**
**      Program by Anchi Bao
**      2010/12/15
*/

#ifndef ANCHI_HEAP_SORT_H
#define ANCHI_HEAP_SORT_H

#include "Sort.h"


//  ============================================================================================================//
//  class Heap
//  ====================
template <typename T>
class Heap {
public:
    Heap (const int size);
    void insert(const T val);
    T poptop(void);
private:
    T *data;
    int size;
};

template <typename T>
Heap<T>::Heap(const int size) {
data = new T [size+7];
    this->size = 0;
}

template <typename T>
void Heap<T>::insert(const T val) {
    int p = ++size;
    
    while (p > 1  &&  data[p>>1] > val) {
        data[p] = data[p>>1];
        p >>= 1;
    }
    data[p] = val;
}

template <typename T>
T Heap<T>::poptop(void) {
    T res = data[1],
      tmp = data[size--];
    int p = 1,
        q = p << 1;
    if (data[q+1] < data[q])
        q++;
    while (q<=size && data[q]<tmp) {
        data[p] = data[q];
        p = q;
        q <<= 1;
        if (q+1<=size  &&  data[q+1] < data[q])
            q++;
    }
    data[p] = tmp;
    return res;
}

//  ============================================================================================================//
//  class HeapSort
//  ====================
template <typename T>
class HeapSort : public Sort<T> {
public:
    static void sort (T* head, T* back);
};

template <typename T>
void HeapSort<T>::sort (T* head, T* back){
    int size = back-head;
    if (size <= 1) return;

    Heap<T> tmpHeap(size);

    T *i;
    for (i=head; i<back; i++)
        tmpHeap.insert(*i);
    for (i=head; i<back; i++)
        *i = tmpHeap.poptop();

}

#endif