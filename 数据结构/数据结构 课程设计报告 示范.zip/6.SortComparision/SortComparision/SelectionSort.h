/*
**      Simple Selection Sort - O(n^2)
**      Sorts range [head...back)
**
**      Usage:
**              #include "SelectionSort.h"
**              ...
**              int * Data = new int[N];
**              ...
**              SelectionSort<int>::sort(Data, Data+N);
**
**      Program by Anchi Bao
**      2010/12/14
*/

#ifndef ANCHI_SELECTION_SORT_H
#define ANCHI_SELECTION_SORT_H

#include "Sort.h"

template <typename T>
class SelectionSort : public Sort<T> {
public:
    static void sort (T* head, T* back);
};

template <typename T>
void SelectionSort<T>::sort (T* head, T* back){
    int size = back-head;
    if (size <= 1) return;

    T *i, *j, *p;
    for (i=head; i<back; i++) {
        p = i;
        for (j=i+1; j<back; j++)
            if (*j < *p)
                p = j;
        if (i != p)
            swap(i, p);
    }
}

#endif