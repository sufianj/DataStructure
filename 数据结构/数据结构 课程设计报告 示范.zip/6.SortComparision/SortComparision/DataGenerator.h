/*
**      Random Data Generator
**      Generates random data in given range [lowerBound...upperBound] and store into given memory space.
**      Supports type integer (including unsigned/short/long) and char.
**
**      Usage:
**              #include "DataGenerator.h"
**              ...
**              int Data[10];
**              DataGenerator<int>::makeData(Data, 10, 0, 9);
**
**      Program by Anchi Bao
**      2010/12/15
*/

#ifndef ANCHI_DATA_GENERATOR_H
#define ANCHI_DATA_GENERATOR_H

#include "CommonResource.h"

template <typename T>
class DataGenerator {
public:
    static bool makeData(T* buffer, const int amount, const T lowerBound, const T upperBound);
private:
};

template <typename T>
bool DataGenerator<T>::makeData(T* buffer, const int amount, const T lowerBound, const T upperBound) {
    //  Error: amount < 0
    if (amount < 0) {
        cout << "Given amount is less than 0! " << endl;
        return false;
    }
    //  Error: bound illegal
    if (upperBound < lowerBound) {
        cout << "Bound Illegal! " << endl;
        return false;
    }
    //  Error: storage error
    if (buffer == NULL) {
        cout << "Given storage space is null! " << endl;
        return false;
    }

    //  Reset randomizer with current system time
    srand(time(0));

    //cout << "Now generating random data and outputing..." << endl;
    //opf << amount << endl;
    for (int i=0; i<amount; i++)
        *(buffer+i) = lowerBound + rand()*rand()%(upperBound - lowerBound + 1);

    return true;
}


#endif