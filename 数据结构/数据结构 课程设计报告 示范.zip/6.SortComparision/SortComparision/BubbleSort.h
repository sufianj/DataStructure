/*
**      Simple Bubble Sort - O(n^2)
**      Sorts range [head...back)
**
**      Usage:
**              #include "BubbleSort.h"
**              ...
**              int * Data = new int[N];
**              ...
**              BubbleSort<int>::sort(Data, Data+N);
**
**      Program by Anchi Bao
**      2010/12/14
*/

#ifndef ANCHI_BUBBLE_SORT_H
#define ANCHI_BUBBLE_SORT_H

#include "Sort.h"

template <typename T>
class BubbleSort : public Sort<T> {
public:
    static void sort (T* head, T* back);
};

template <typename T>
void BubbleSort<T>::sort (T* head, T* back){
    int size = back-head;
    if (size <= 1) return;

    T *i, *j;
    for (i=head; i<back; i++)
        for (j=back-1; j>i; j--)
            if (*j < *(j-1))
                swap(j, j-1);
}

#endif