/*
**      2-Way Merge Sort - O(n*logn)
**      Sorts range [head...back)
**
**      Usage:
**              #include "MergeSort.h"
**              ...
**              int * Data = new int[N];
**              ...
**              MergeSort<int>::sort(Data, Data+N);
**
**      Program by Anchi Bao
**      2010/12/14
*/

#ifndef ANCHI_MERGE_SORT_H
#define ANCHI_MERGE_SORT_H

#include "Sort.h"

template <typename T>
class MergeSort : public Sort<T> {
public:
    static void sort (T* head, T* back);
};

template <typename T>
void MergeSort<T>::sort (T* head, T* back){
    int size = back-head;
    if (size <= 1) return;

    T *bufferA = head,
      *bufferB = head+(size>>1),
      *bufferC = head+(size>>1),
      *bufferD = back;
    sort(bufferA, bufferB);
    sort(bufferC, bufferD);

    T *temp = new T [size],
      *insp = temp;
    while (insp-temp < size  &&  bufferA < bufferB  &&  bufferC < bufferD) {
        while (*bufferA <= *bufferC  &&  bufferA < bufferB)
            *(insp++) = *(bufferA++);
        while (*bufferC <= *bufferA  &&  bufferC < bufferD)
            *(insp++) = *(bufferC++);
    }
    while (bufferA < bufferB)
        *(insp++) = *(bufferA++);
    while (bufferC < bufferD)
        *(insp++) = *(bufferC++);

    for (int i=0; i<size; i++)
        *(head+i) = *(temp+i);
}

#endif