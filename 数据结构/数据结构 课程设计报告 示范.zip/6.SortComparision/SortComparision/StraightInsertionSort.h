/*
**      Straight Insertion Sort - O(n^2)
**      Sorts range [head...back)
**
**      Usage:
**              #include "StraightInsertionSort.h"
**              ...
**              int * Data = new int[N];
**              ...
**              StraightInsertionSort<int>::sort(Data, Data+N);
**
**      Program by Anchi Bao
**      2010/12/14
*/

#ifndef ANCHI_STRAIGHT_INSERTION_SORT_H
#define ANCHI_STRAIGHT_INSERTION_SORT_H

#include "Sort.h"

template <typename T>
class StraightInsertionSort : public Sort<T> {
public:
    static void sort (T* head, T* back);
};

template <typename T>
void StraightInsertionSort<T>::sort (T* head, T* back){
    int size = back-head;
    if (size <= 1) return;

    T *i, *j, *p;
    T t;
    for (i=head+1; i<back; i++) {
        t = *i;
        p = head;
        while (*p < t) p++;
        for (j=i; j>p; j--)
            *j = *(j-1);
        *p = t;
    }
}

#endif