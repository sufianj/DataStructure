/*
**      Binary Insertion Sort - O(n^2)
**      Sorts range [head...back)
**
**      Usage:
**              #include "BinaryInsertionSort.h"
**              ...
**              int * Data = new int[N];
**              ...
**              BinaryInsertionSort<int>::sort(Data, Data+N);
**
**      Program by Anchi Bao
**      2010/12/14
*/

#ifndef ANCHI_Binary_INSERTION_SORT_H
#define ANCHI_Binary_INSERTION_SORT_H

#include "Sort.h"

template <typename T>
class BinaryInsertionSort : public Sort<T> {
public:
    static void sort (T* head, T* back);
private:
    static T* binarySearch (T* lb, T* ub, T val);
};

template <typename T>
void BinaryInsertionSort<T>::sort (T* head, T* back){
    int size = back-head;
    if (size <= 1) return;

    T *i, *j, *p;
    T t;
    for (i=head+1; i<back; i++) {
        t = *i;
        p = binarySearch(head, i-1, t);
        if (p == NULL)
            continue;
        for (j=i; j>p; j--)
            *j = *(j-1);
        *p = t;
    }
}

template <typename T>
T* BinaryInsertionSort<T>::binarySearch(T* lb, T* ub, T val) {
    if (lb == ub) {
        if (*lb < val)
            return NULL;
        else
            return lb;
    }

    T* mid = lb + ((ub-lb)>>1);
    if (*mid >= val)
        return binarySearch(lb, mid, val);
    else
        return binarySearch(mid+1, ub, val);
}

#endif