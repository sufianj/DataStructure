#ifndef ANCHI_SORTING_METHODS_H
#define ANCHI_SORTING_METHODS_H

#include "StraightInsertionSort.h"
#include "BinaryInsertionSort.h"
#include "BubbleSort.h"
#include "QuickSort.h"
#include "SelectionSort.h"
#include "HeapSort.h"
#include "RadixSort.h"
#include "MergeSort.h"

#endif