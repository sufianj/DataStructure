/*
**      Integer Radix Sort - O(n*k)
**      Sorts range [head...back)
**
**      Usage:
**              #include "RadixSort.h"
**              ...
**              int * Data = new int[N];
**              ...
**              RadixSort::sort(Data, Data+N);
**
**      Program by Anchi Bao
**      2010/12/15
*/

#ifndef ANCHI_Radix_SORT_H
#define ANCHI_Radix_SORT_H

#include "Sort.h"

#include <memory>
using namespace std;

#define EnLarge 100

//  ============================================================================================================//
//  class Queue
//  ====================
class Queue {
public:
    bool init(void);
    bool empty(void);
    void enQueue(int obj);
    int deQueue(void);
private:
    int *buff, *head, *back;
    int size;
};

bool Queue::init (void) {
    buff = new int [EnLarge];
    if (buff == NULL)
        return false;
    head = buff;
    back = head;
    size = EnLarge;
    return true;
}

bool Queue::empty (void) {
    return back == head;
}

void Queue::enQueue (int obj) {
    if (size == back-head) {
        int *newBuff = new int [size+EnLarge],
            *oldBuff = head;
        memcpy(newBuff, oldBuff, sizeof(int)*size);
        buff = newBuff;
        head = buff;
        back = head + size;
        size = size + EnLarge;
    }
    *(back ++) = obj;
}

int Queue::deQueue (void ) {
    --size;
    return *(head ++);
}

//  ============================================================================================================//
//  class RadixSort
//  ====================
class RadixSort : public Sort<int> {
public:
    static void sort (int* head, int* back);
private:
    static Queue *Q;
};

void RadixSort::sort (int* head, int* back){
    int size = back-head;
    if (size <= 1) return;

    bool finished;
    int *i;
    int ord, DIV=1;
    do {
        for (ord=0; ord<=9; ord++)
            Q[ord].init();
        for (i=head; i<back; i++) {
            ord = ( (*i)/DIV ) % 10;
            Q[ord].enQueue(*i);
        }
        for (ord=0, i=head; ord<=9; ord++)
            while (!Q[ord].empty())
                *(i ++) = Q[ord].deQueue();

        DIV *= 10;
        finished = true;
        for (i=head; i<back; i++) {
            if ((*i)/DIV > 0) {
                finished = false;
                break;
            }
        }
    } while (!finished);
}

Queue * RadixSort::Q = new Queue[10];

#endif