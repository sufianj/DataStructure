/*
**      Sort Comparision
**      Test the performance of different sorting methods by sorting integers.
**
**      Include:
**          1.Straight Insertion Sort
**          2.Binary Insertion Sort
**          3.Simple Bubble Sort
**          4.Improved Quick Sort
**          5.Simple Selection Sort
**          6.Binary Heap Sort
**          7.Numerical Radix Sort
**          8.Binary Merge Sort
**
**      All sorting methods above are written with template method EXCLUDING Radix Sort.
**
**      Program by Anchi Bao
**      2010/12/15
*/

#include "CommonResource.h"
#include "DataGenerator.h"
#include "SortingMethods.h"

#define SORT_AMOUNT 30000

char MethodName[9][50] = {
                            "",
                            "1.Straight Insertion Sort  |  O(n^2)",
                            "2.Binary Insertion Sort    |  O(n^2)",
                            "3.Simple Bubble Sort       |  O(n^2)",
                            "4.Improved Quick Sort      |  O(n*logn)",
                            "5.Simple Selection Sort    |  O(n^2)",
                            "6.Binary Heap Sort         |  O(n*logn)",
                            "7.Integer Radix Sort       |  O(n*lgMaxval)",
                            "8.Binary Merge Sort        |  O(n*logn)"
                         };

char OutputFile[9][40] = {
                            "",
                            "1.Straight Insertion Sort.txt",
                            "2.Binary Insertion Sort.txt",
                            "3.Simple Bubble Sort.txt",
                            "4.Improved Quick Sort.txt",
                            "5.Simple Selection Sort.txt",
                            "6.Binary Heap Sort.txt",
                            "7.Integer Radix Sort.txt",
                            "8.Binary Merge Sort.txt"
                         };

//  This class is used to storage time cost of every sorting methods.
class TestStatus {
public:
    double totalTime,
           lastTime;
    int runs;
    int ord;
    bool operator < (TestStatus obj);
    TestStatus();
    void Reset();
};

TestStatus::TestStatus () {
    totalTime = lastTime = 0.00;
    runs = ord = 0;
}

bool TestStatus::operator < (TestStatus obj) {
    return this->lastTime < obj.lastTime;
}

TestStatus Status[9], TmpStatus[9];

int Size[] = {0, 500, 1000, 2000, 3000, 5000, 10000, 15000, 20000, 25000, 30000};

double testSort(int ord, int* buff, int size);



//  ============================================================================================================//
//  main
//  ====================
int main () {
    
    freopen("output.txt", "w", stdout);

    int i, j;

    int *Data;

    //  Methods testment

    for (i=1; i<=8; i++)
        Status[i].ord = i;

    for (j=1; j<=10; j++) {

        Data = new int [ Size[j] ];

        DataGenerator<int>::makeData(Data, Size[j], 0, 99999);

        system("cls");
        cout << "Now we're running Test #" << j << ". " << endl;
        cout << "Data type = INT, data size = " << Size[j] << ". " << endl << endl;

        for (i=1; i<=8; i++) {
            Status[i].lastTime = testSort(i, Data, Size[j]);
            Status[i].totalTime += Status[i].lastTime;
            Status[i].runs ++;
        }

        system("cls");

        memcpy(TmpStatus, Status, sizeof(TestStatus)*9);
        SelectionSort<TestStatus>::sort(TmpStatus+1, TmpStatus+9);

        cout << "Test #" << j << endl;
        cout << "Data type = INT, data size = " << Size[j] << ". " << endl;
        cout << "Speed ranking: " << endl << endl << endl;
        cout << "  Rank |  Time   |  Method                    |  Complexity" << endl;
        cout << "-------+---------+----------------------------+-----------------" << endl;
        for (int i=1; i<=8; i++) 
            cout << "  No." << i << " | "
            << setiosflags(ios::fixed) << setprecision(4) << TmpStatus[i].lastTime << "s | "
            << MethodName[ TmpStatus[i].ord ]
            << endl;
        cout << endl << endl << endl << endl << endl << endl;
        system("pause");

        delete []Data;
    }

    cout << endl << endl << endl << endl;
    cout << "All Tests Finished. Press anykey to view the report." << endl << endl;
    system("pause");

    //  Methods comparision
    system("cls");

    for (i=1; i<=8; i++)
        Status[i].lastTime = Status[i].totalTime;

    SelectionSort<TestStatus>::sort(Status+1, Status+9);

    cout << "Total speed ranking: " << endl << endl << endl;
    cout << "  Rank |  Total Time  |  Method                    |  Complexity" << endl;
    cout << "-------+--------------+----------------------------+-----------------" << endl;
    for (int i=1; i<=8; i++) 
        cout << "  No." << i << " | "
        << setw(10) << setiosflags(ios::fixed) << setprecision(4) << Status[i].totalTime << "s  | "
        << MethodName[ Status[i].ord ]
        << endl;
    cout << endl << endl << endl << endl << endl << endl;
    system("pause");
    return 0;
}

//  ============================================================================================================//
//  Sort Testing
//  ====================
double testSort (int ord, int* buff, int size){

    int* Temp = new int [size];

    memcpy(Temp, buff, sizeof(int)*size);
    ofstream opf(OutputFile[ord]);
        
    cout << "==========================================================" << endl << endl;
    cout << MethodName[ord] << endl << endl;
    cout << "----------------------------------------------------------" << endl;
    cout << "Here we start..." << endl;

    
    long startT, endT;
    double costT;

    startT = clock();

    switch (ord) {
    case 1: {
                StraightInsertionSort<int>::sort(Temp, Temp+size);
                break;
            }
    case 2: {
                BinaryInsertionSort<int>::sort(Temp, Temp+size);
                break;
            }
    case 3: {
                BubbleSort<int>::sort(Temp, Temp+size);
                break;
            }
    case 4: {
                QuickSort<int>::sort(Temp, Temp+size);
                break;
            }
    case 5: {
                SelectionSort<int>::sort(Temp, Temp+size);
                break;
            }
    case 6: {
                HeapSort<int>::sort(Temp, Temp+size);
                break;
            }
    case 7: {
                RadixSort::sort(Temp, Temp+size);
                break;
            }
    case 8: {
                MergeSort<int>::sort(Temp, Temp+size);
                break;
            }
    }

    endT = clock();
    costT = ((double)(endT-startT)) / 1000.0;

    cout << "Sort Finished! " << size << " integers sorted in " 
         << setiosflags(ios::fixed) << setprecision(4) << costT << "s." << endl << endl;
    cout << "Outputing resault to: "<< OutputFile[ord] << "..." << endl;

    opf << "Straight Insertion Sort: " << size << " integers sorted in " 
        << setiosflags(ios::fixed) << setprecision(4) << costT << "s." << endl << endl;

    for (int i=0; i<size; i++) {
        opf << Temp[i] << ' ';
        if (i%20 == 19)
            opf << endl;
    }
    opf << endl;
    opf.close();
    
    cout << "Output finished!" << endl << endl;
    system("pause");
    
    return costT;
}