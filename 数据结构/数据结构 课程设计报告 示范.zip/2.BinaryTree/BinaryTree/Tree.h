#ifndef ANCHI_TREE_H
#define ANCHI_TREE_H

#define INIT_SIZE 1000

#include "TreeNode.h"

class Tree {

public:
    Tree (void);

    void init(istream&);

    const TreeNode* root (void);
    TreeNode* findNode (int);
    
    void preOrderTraverse_R (ostream&, const TreeNode*) const;
    void preOrderTraverse_S (ostream&, const TreeNode*) const;
    void midOrderTraverse_R (ostream&, const TreeNode*) const;
    void midOrderTraverse_S (ostream&, const TreeNode*) const;
    void postOrderTraverse_R (ostream&, const TreeNode*) const;
    void postOrderTraverse_S (ostream&, const TreeNode*) const;
    void levelOrderTraverse_R (ostream&, const TreeNode*) const;
    void levelOrderTraverse_Q (ostream&, const TreeNode*) const;

    const int height (const TreeNode*) const;
    const int nodecnt (const TreeNode*) const;
    const int leafcnt (const TreeNode*) const;
    const int luxuriance (const TreeNode*) const;
    bool isCBT (const TreeNode*) const;

    void display (ostream&, const TreeNode*);

private:
    TreeNode *node;
    int size;

};

#endif