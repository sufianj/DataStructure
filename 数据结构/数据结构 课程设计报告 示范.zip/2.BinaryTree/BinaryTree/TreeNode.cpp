#include "TreeNode.h"

TreeNode::TreeNode (void) {
    idx = 0;
    lc = rc = NULL;
}

TreeNode::TreeNode (int idx, TreeNode* lc, TreeNode* rc) {
    this->idx = idx;
    this->lc = lc;
    this->rc = rc;
}

const int TreeNode::getIndex (void) const{
    return idx;
}

const TreeNode* TreeNode::getLC (void) const{
    return lc;
}

const TreeNode* TreeNode::getRC (void) const{
    return rc;
}

void TreeNode::setIndex (const int idx) {
    this->idx = idx;
}

void TreeNode::linkLC (const TreeNode* lc) {
    this->lc = lc;
}

void TreeNode::linkRC (const TreeNode* rc) {
    this->rc = rc;
}

void TreeNode::linkChild (const TreeNode* lc, const TreeNode* rc) {
    this->lc = lc;
    this->rc = rc;
}

void TreeNode::swapChild (void) {
    swap(lc, rc);
}

ostream& operator << (ostream& opt, const TreeNode& obj) {
    opt << setw(2) << obj.idx;
    return opt;
}
