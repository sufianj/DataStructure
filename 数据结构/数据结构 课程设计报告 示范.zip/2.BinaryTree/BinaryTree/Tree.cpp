#include "Tree.h"

Tree::Tree (void) {
}

const TreeNode* Tree::root (void) {
    return node+1;
}

TreeNode* Tree::findNode (int idx) {
    if (idx == 0)
        return NULL;
    return node+idx;
}

void Tree::init (istream& ipt) {
    ipt >> size;
    node = new TreeNode [size];
    int i, idx, lx ,rx;
    for (i=1; i<=size; i++) {
        ipt >> idx >> lx >> rx;
        node[idx].setIndex(idx);
        node[idx].linkChild(findNode(lx), findNode(rx));
    }
}

void Tree::preOrderTraverse_R (ostream& opt, const TreeNode* r) const {
	if(r == NULL)
		return;
	opt << *r << " ";
    preOrderTraverse_R(opt, r->getLC() );
    preOrderTraverse_R(opt, r->getRC() );
}

void Tree::preOrderTraverse_S (ostream& opt, const TreeNode* r) const {
	if(r == NULL)
		return;
	const TreeNode *temp;
	Stack<const TreeNode*> S;
    S.push(r);

    while (!S.empty()) {		
        temp = S.get();
		opt << *temp << " ";

        if (temp->getLC() != NULL) {
            S.push(temp->getLC());
            continue;
        }
        temp = S.pop();
        if (temp->getRC() != NULL) {
            S.push(temp->getRC());
            continue;
        }
        do {
            temp = S.pop();
        } while (temp->getRC()==NULL && !S.empty());

        if (S.empty() && temp->getRC()==NULL)
            break;
        else
            S.push(temp->getRC());
	}
}

void Tree::midOrderTraverse_R (ostream& opt, const TreeNode* r) const {
	if(r == NULL)
		return;
    midOrderTraverse_R(opt, r->getLC() );
	opt << *r << " ";
    midOrderTraverse_R(opt, r->getRC() );
}

void Tree::midOrderTraverse_S (ostream& opt, const TreeNode* r) const {
	if(r == NULL)
		return;
	const TreeNode *temp;
	Stack<const TreeNode*> S;
    S.push(r);

    while (!S.empty()) {		
        temp = S.get();

        if (temp->getLC() != NULL) {
            S.push(temp->getLC());
            continue;
        }
        temp = S.pop();
        opt << *temp << " ";
        if (temp->getRC() != NULL) {
            S.push(temp->getRC());
            continue;
        }
        do {
            temp = S.pop();
            opt << *temp << " ";
        } while (temp->getRC()==NULL && !S.empty());

        if (S.empty() && temp->getRC()==NULL)
            break;
        else
            S.push(temp->getRC());
	}
}

void Tree::postOrderTraverse_R (ostream& opt, const TreeNode* r) const {
	if(r == NULL)
		return;
    postOrderTraverse_R(opt, r->getLC() );
    postOrderTraverse_R(opt, r->getRC() );
    opt << *r << " ";
}

void Tree::postOrderTraverse_S (ostream& opt, const TreeNode* r) const {
	if(r == NULL)
		return;
	const TreeNode *temp;
    bool *Visit= new bool [size];
    for (int i=1; i<=size; i++)
        Visit[i] = false;
	Stack<const TreeNode*> S;
    S.push(r);

    while (!S.empty()) {		
        temp = S.get();

        if (temp->getLC() != NULL) {
            S.push(temp->getLC());
            continue;
        }

        if (!Visit[temp->getIndex()]  &&  temp->getRC() != NULL) {
            S.push(temp->getRC());
            Visit[temp->getIndex()] = true;
            continue;
        }

        while ((temp->getRC()==NULL || Visit[temp->getIndex()] ) && !S.empty()) {
            temp = S.pop();
            opt << *temp << " ";
            if (S.empty())
                break;
            temp = S.get();
        }
        
        if (S.empty())
            break;
        else {
            S.push(temp->getRC());
            Visit[temp->getIndex()] = true;
        }
	}
}

void Tree::levelOrderTraverse_Q(ostream& opt, const TreeNode* r) const {
	if(r == NULL)
		return;
    Queue<const TreeNode*> Q;
    Q.push(r);
    const TreeNode* p;
    while (!Q.empty()) {
        p = Q.pop();
        if (p==NULL)
            continue;
        opt << *p << " ";
        Q.push(p->getLC());
        Q.push(p->getRC());
    }
}

const int Tree::height(const TreeNode* r) const {
    if (r == NULL)
        return 0;
    return max(height(r->getLC()), height(r->getRC())) + 1;
}

const int Tree::luxuriance (const TreeNode* r) const {
    if (r == NULL)
        return 0;
    return luxuriance(r->getLC()) + luxuriance(r->getRC()) + nodecnt(r->getLC()) + nodecnt(r->getRC());
}

const int Tree::nodecnt (const TreeNode* r) const {
    if (r == NULL)
        return 0;
    return nodecnt(r->getLC()) + nodecnt(r->getRC()) + 1;
}

const int Tree::leafcnt (const TreeNode* r) const {
    if (r == NULL)
        return 0;
    if (r->getLC()==NULL && r->getRC()==NULL)
        return 1;
    return leafcnt(r->getLC()) + leafcnt(r->getRC());
}

bool Tree::isCBT (const TreeNode* r) const {
    if (r == NULL)
        return true;
    Queue<const TreeNode*> Q;
    Q.push(r);
    const TreeNode* p;
    bool succ = true;
    while (!Q.empty()) {
        p = Q.pop();
        if (p==NULL) {
            succ = false;
            continue;
        }
        else if (!succ)
            return false;
        Q.push(p->getLC());
        Q.push(p->getRC());
    }
    return true;
}

void putspace (ostream& opt, int cnt) {
    while (cnt-- > 0)
        opt << " ";
}

void Tree::display (ostream& opt, const TreeNode* r) {
	if(r == NULL)
		return;
    Queue<const TreeNode*> Q;
    Q.push(r);

    int limit = 1,
        cnt = 1,
        width = 32;
    bool levelEmpty = true;

    const TreeNode* p;
    while (!Q.empty()) {
        cnt ++;
        p = Q.pop();
        putspace(opt, width);
        
        if (p == NULL) {
            opt << "  ";
            Q.push(NULL);
            Q.push(NULL);
        }
        else {
            levelEmpty = false;
            opt << *p;
            Q.push(p->getLC());
            Q.push(p->getRC());
        }
        
        putspace(opt, width-2);
        if (cnt > limit) {
            if (levelEmpty)
                break;
            else
                levelEmpty = true;
            limit = limit*2 + 1;
            width /= 2;
            opt << endl;
        }
    }
}