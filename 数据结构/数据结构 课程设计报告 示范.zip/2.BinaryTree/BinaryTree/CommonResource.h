#ifndef ANCHI_COMMON_RESOURCE_H
#define ANCHI_COMMON_RESOURCE_H

#include <iostream>
#include <fstream>
#include <iomanip>

#include <cstdlib>
#include <cmath>

#include <string>
#include <memory>
#include <iterator>

#include "Stack.h"
#include "Queue.h"

using namespace std;

#endif