/*
**      Binary Tree
**      Contains basic binary tree and basic functions.
**
**      Include:
**          1.Pre-Order Traverse (Recursion)
**          2.Pre-Order Traverse (Non-recursion)
**          3.Mid-Order Traverse (Recursion)
**          4.Mid-Order Traverse (Non-Recursion)
**          5.Post-Order Traverse (Recursion)
**          6.Post-Order Traverse (Non-Recursion)
**          7.Level-Order Traverse (Non-Recursion)
**          8.Tree Display
**          9.Children Swapping
**
**      And calculates:
**          1.Node amount
**          2.Leaf amount
**          3.Height
**          4.Luxuriance:
**
**      Program by Anchi Bao
**      2010/12/30
*/

#include "CommonResource.h"
#include "Tree.h"
#include "TreeNode.h"

int main () {

    Tree BiTree;

    ifstream ipf("input.txt");
    BiTree.init(ipf);
    ipf.close();

    freopen("output.txt", "w", stdout);

    const TreeNode* Root = BiTree.root();

    cout << "Node amount: " << BiTree.nodecnt(Root) << endl;
    cout << "Leaf amount: " << BiTree.leafcnt(Root) << endl;

    cout << "Height: " << BiTree.height(Root) << endl;
    cout << "Luxuriance: " << BiTree.luxuriance(Root) << endl;

    if (BiTree.isCBT(Root))
        cout << "This tree is a Complete Binary Tree. " << endl;
    else
        cout << "This tree is NOT a Complete Binary Tree. " << endl;

    cout << endl << endl;
    
    cout << "Pre-Order Traverse (Recursion)" << endl;
    BiTree.preOrderTraverse_R(cout, Root);
    cout << endl << endl;
    cout << "Pre-Order Traverse (Non-recursion)" << endl;
    BiTree.preOrderTraverse_S(cout, Root);
    cout << endl << endl;

    cout << "Mid-Order Traverse (Recursion)" << endl;
    BiTree.midOrderTraverse_R(cout, Root);
    cout << endl << endl;
    cout << "Mid-Order Traverse (Non-recursion)" << endl;
    BiTree.midOrderTraverse_S(cout, Root);
    cout << endl << endl;

    cout << "Post-Order Traverse (Recursion)" << endl;
    BiTree.postOrderTraverse_R(cout, Root);
    cout << endl << endl;
    cout << "Post-Order Traverse (Non-recursion)" << endl;
    BiTree.postOrderTraverse_S(cout, Root);
    cout << endl << endl;

    cout << "Level-Order Traverse (Non-recursion)" << endl;
    BiTree.levelOrderTraverse_Q(cout, Root);
    cout << endl << endl;

    cout << "Tree Display: " << endl;
    BiTree.display(cout, Root);
    cout << endl << endl;

    cout << "Now swap the children of Node #1. " << endl;
    BiTree.findNode(1)->swapChild();
    
    cout << "Tree Display: " << endl;
    BiTree.display(cout, Root);
    cout << endl << endl;
    
    system("pause");

    return 0;
}