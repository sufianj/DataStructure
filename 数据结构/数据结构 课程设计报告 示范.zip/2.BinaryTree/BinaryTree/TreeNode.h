#ifndef ANCHI_TREE_NODE_H
#define ANCHI_TREE_NODE_H

#include "CommonResource.h"

class TreeNode {

public:
    TreeNode(void);
    TreeNode(int, TreeNode*, TreeNode*);

    const int getIndex (void) const;
    const TreeNode* getLC (void) const;
    const TreeNode* getRC (void) const;

    void setIndex (const int);
    void linkLC (const TreeNode*);
    void linkRC (const TreeNode*);
    void linkChild (const TreeNode*, const TreeNode*);
    void swapChild (void);

    friend ostream& operator << (ostream&, const TreeNode&);

private:
    int idx;
    const TreeNode *lc,
                   *rc;

};

#endif