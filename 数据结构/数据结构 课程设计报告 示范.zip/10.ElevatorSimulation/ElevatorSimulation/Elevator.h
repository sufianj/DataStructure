#ifndef ANCHI_ELEVATOR_H
#define ANCHI_ELEVATOR_H

#include "CommonResource.h"
#include "Passenger.h"

class Elevator {
public:
    Elevator (void);

    int ID();

    int floor (void);
    bool openIO (void);
    bool openNoIO (void);
    bool longWait (void);
    string state (void);

    void callCar(int floor);

private:
    static int _cnt;
    
    int _ID;

    bool _CallCar[MAX_FLOOR];

    Stack<Passenger*> _PsgStack[MAX_FLOOR];

    int _Floor;
    bool _OpenIO;
    bool _OpenNoIO;
    bool _LongWait;
    string _State;
};

#endif