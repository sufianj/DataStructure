#include "CommonResource.h"

int main () {
    return 0;
}