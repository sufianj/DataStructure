#include "Simulator.h"

void Simulator::tick () {
    int tmp = clock();
    while (clock()-tmp < TICK_LENGTH);
}

void Simulator::Start (void) {
    this->_clockr = 0;
    _startTime = time(NULL);
    
    PsgEvent *p;
    EleEvent *e;
    
    Passenger Psg;
    p = new PsgEnterBuilding(_clockr, Psg);
    _PsgEventQueue.insert(*p);
    
    e = new EleWaitingGround(_clockr, Ele);
    _EleEventQueue.insert(*e);

    Ele = *e;

    while (_clockr < MAX_SIM_TIME) {
        onTick(_clockr);
        tick();
    }
}

void Simulator::windowUpdate (void) {
    time_t _cT = time(NULL) - _startTime;
    tm _dT = *localtime(&_cT);

    char titleStr[1024];
    sprintf(titleStr, "Elevator Simulation - [%02d:%02d:%02d]", _dT.tm_min, _dT.tm_sec, (_cT%1000)/10);
    SetConsoleTitle(LPCWSTR(titleStr));
}

void Simulator::onTick (int currentTime) {
    
    windowUpdate();

    PsgEvent *p = &_PsgEventQueue.gettop();
    while (!_PsgEventQueue.empty() && p->timer()<=currentTime) {
        p = &_PsgEventQueue.poptop();

        if (p->type() == "PsgEnterBuilding")
            onPsgEnterBuilding(p);
        else if (p->type() == "PsgStartWaiting") 
            onPsgStartWaiting(p);
        else if (p->type() == "PsgStartQueuing")
            onPsgStartQueuing(p);
        else if (p->type() == "PsgGiveupWaiting")
            onPsgGiveupWaiting(p);
        else if (p->type() == "PsgEnterElevator")
            onPsgEnterElevator(p);
        else if (p->type() == "PsgLeaveBuilding")
            onPsgLeaveBuilding(p);

        p = &_PsgEventQueue.gettop();
    }

    EleEvent *e = &_EleEventQueue.gettop();
    while (!_EleEventQueue.empty() && e->timer()<=currentTime) {
        e = &_EleEventQueue.poptop();
        Ele = *e;

        if (e->type() == "EleWaitingGround")
            onEleWaitingGround(e);
        else if (e->type() == "EleStatusChange")
            onEleStatusChange(e);
        else if (e->type() == "EleOpenTheDoor")
            onEleOpenTheDoor(e);
        else if (e->type() == "ElePassengersIO")
            onElePassengersIO(e);
        else if (e->type() == "EleCloseTheDoor")
            onEleCloseTheDoor(e);
        else if (e->type() == "EleReadyToMove")
            onEleReadyToMove(e);
        else if (e->type() == "EleMoveUpstair")
            onEleMoveUpstair(e);
        else if (e->type() == "EleMoveDownstair")
            onEleMoveDownstair(e);
        else if (e->type() == "EleStartWaiting")
            onEleStartWaiting(e);

        e = &_EleEventQueue.gettop();
    }
}

//  [M1] A passenger enters the building
void Simulator::onPsgEnterBuilding(PsgEvent* p){

    int curTime = p->timer();
    
    //  New passenger enters the building.
    p->getPsg();

    //  Add Event: Start queuing for elevator
    PsgStartWaiting newPsgEvent(curTime, *p);
    _PsgEventQueue.insert(newPsgEvent);

    //  Add Event: Next passenger's entrance.
    PsgEnterBuilding nexPsgEvent(curTime+newPsg.InterTime(), Passenger());
    _PsgEventQueue.insert(nexPsgEvent);
}

//  [M2] A passenger starts waiting for the elevator
void Simulator::onPsgStartWaiting(PsgEvent* p) {

    int curTime = p->timer();

    PsgStartQueuing newPsgEvent(curTime, *p);
    _PsgEventQueue.insert(newPsgEvent);

    //  Case 1
    if (Ele.floor()==p->InFloor()  &&  Ele.type()=="EleCloseTheDoor") {
        EleOpenTheDoor newEleEvent(curTime, Ele);
        _EleEventQueue.insert(newEleEvent);
    }
    //  Case 2
    else if (Ele.floor()==p->InFloor()  &&  Ele.openIO()) {
        ElePassengersIO newEleEvent(curTime, Ele);
        _EleEventQueue.insert(newEleEvent);
    }
    //  Case 3
    else {
        Ele.callCar(p->InFloor());
    }
}

//  [M3] A passenger stands into the queue at a floor
void Simulator::onPsgStartQueuing(PsgEvent* p){
    int curTime = p->timer();

    onPsgGiveupWaiting newPsgEvent(curTime+p->GiveupTime(), *p);
    _PsgEventQueue.insert(newPsgEvent);

    _PsgQueue[p->InFloor()].push(*p);
}

//  [M4] A passenger gives up waiting for the elevator
void Simulator::onPsgGiveupWaiting(PsgEvent* p){
    int curTime = p->timer();

    if (Ele.floor()==p->InFloor()  &&  Ele.openIO())
        return;

    
}

void Simulator::onPsgEnterElevator(PsgEvent* p){
    
}

void Simulator::onPsgLeaveBuilding(PsgEvent* p){
    
}