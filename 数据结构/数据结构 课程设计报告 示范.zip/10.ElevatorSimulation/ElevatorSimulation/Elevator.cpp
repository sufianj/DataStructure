#include "Elevator.h"

int Elevator::_cnt = 0;

Elevator::Elevator (void) {
    this->_ID = ++ _cnt;
    this->_Floor = 1;
    this->_OpenIO = false;
    this->_OpenNoIO = false;
    this->_LongWait = false;
    this->_State = "Idle";
};

int Elevator::ID (void) {
    return this->_ID;
}

int Elevator::floor (void) {
    return this->_Floor;
}

bool Elevator::openIO (void) {
    return this->_OpenIO;
}

bool Elevator::openNoIO (void) {
    return this->_OpenNoIO;
}

bool Elevator::longWait (void) {
    return this->_LongWait;
}

string Elevator::state (void) {
    return this->_State;
}

void Elevator::callCar(int floor) {
    _CallCar[floor] = true;
}