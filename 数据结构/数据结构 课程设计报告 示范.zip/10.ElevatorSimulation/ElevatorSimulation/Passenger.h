#ifndef HEADER_PASSENGER_H
#define HEADER_PASSENGER_H

#include "CommonResource.h"

class Passenger {
public:
    Passenger(void);

    void getPsg(void);

    int ID (void);

    int InFloor (void);
    int OutFloor (void);
    int GiveupTime (void);
    int InterTime (void);

    void leave (void);
    bool left (void);

private:
    static int _cnt;

    int _ID;

    int _InFloor;
    int _OutFloor;
    int _GiveupTime;
    int _InterTime;

    bool _left;

    static ifstream _filePassenger;
};

#endif