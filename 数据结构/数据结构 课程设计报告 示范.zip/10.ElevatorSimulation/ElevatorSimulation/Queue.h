/*
**      LIFO - Queue
**
**      Usage:
**          #include "Queue.h"
**          ...
**          Queue<int> Q;
**          ...
**          Q.push(100);
**          ...
**          int val = Q.get(),
**              tmp = Q.pop();
**
**      Program by Anchi Bao
**      2010/12/15
*/

#ifndef ANCHI_QUEUE_H
#define ANCHI_QUEUE_H

#define INIT_QUEUE_SIZE 100

#include <memory>

using namespace std;

template <typename T>
class Queue {
public:
    Queue (void);

    bool empty (void);
    
    void push (const T);
    const T pop (void);
    const T get (void);

private:
    T *data,
      *head,
      *back;
    int size;
};

template <typename T>
Queue<T>::Queue (void) {
    data = new T [INIT_QUEUE_SIZE];
    head = data;
    back = data;
    size = INIT_QUEUE_SIZE;
}

template <typename T>
bool Queue<T>::empty (void) {
    return back-head == 0;
}

template <typename T>
void Queue<T>::push (const T obj) {
    if (back-head == size) {
        data = new T [size + INIT_QUEUE_SIZE];
        memcpy(data, head, sizeof(T)*size);
        head = data;
        back = head + size;
        size = size + INIT_QUEUE_SIZE;
    }
    *(back++) = obj;
}

template <typename T>
const T Queue<T>::pop (void) {
    --size;
    return *(head++);
}

template <typename T>
const T Queue<T>::get (void) {
    return *head;
}

#undef INIT_QUEUE_SIZE

#endif