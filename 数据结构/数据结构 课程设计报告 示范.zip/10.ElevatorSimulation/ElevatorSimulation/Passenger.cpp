#include "Passenger.h"

int Passenger::_cnt = 0;

ifstream Passenger::_filePassenger ("passenger.txt");

Passenger::Passenger (void) {
    _ID = _InFloor = _OutFloor = _GiveupTime = _InterTime = 0;
    _left = false;
}

void Passenger::getPsg (void) {
    this->_ID = ++ _cnt;
    _filePassenger >> _InFloor >> _OutFloor >> _GiveupTime >> _InterTime;
}

int Passenger::ID (void) {
    return this->_ID;
}

int Passenger::InFloor (void) {
    return this->_InFloor;
}

int Passenger::OutFloor (void) {
    return this->_OutFloor;
}

int Passenger::GiveupTime (void) {
    return this->_GiveupTime;
}

int Passenger::InterTime (void) {
    return this->_InterTime;
}

bool Passenger::left (void) {
    return this->_left;
}

void Passenger::leave (void) {
    this->_left = true;
}