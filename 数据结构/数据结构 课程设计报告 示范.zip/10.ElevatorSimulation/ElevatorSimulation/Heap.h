/*
**      Improved Binary Heap
**
**      Usage:
**              #include "Heap.h"
**              ...
**              Heap<int> intHeap(100);     //  Creates a heap which can store 100 integers.
**
**      Program by Anchi Bao
**      2010/12/15
*/

#ifndef ANCHI_HEAP_H
#define ANCHI_HEAP_H

#define INIT_HEAP_SIZE 1000

template <typename T>
class Heap {
public:
    Heap (void);
    void insert (const T val);
    T poptop (void);
    T gettop (void);
    bool empty (void);
private:
    T *data;
    int size, limit;
};

template <typename T>
Heap<T>::Heap (void) {
    data = new T [INIT_HEAP_SIZE+7];
    size = 0;
    limit = INIT_HEAP_SIZE;
    data[0] = T();
}

template <typename T>
void Heap<T>::insert (const T val) {

    if (size == limit) {
        T *buff = new T [limit+INIT_HEAP_SIZE];
        memcpy(buff, data, sizeof(T)*limit);
        data = buff;
        limit += INIT_HEAP_SIZE;
    }

    int p = ++size;
    
    while (p > 1  &&  val < data[p>>1]) {
        data[p] = data[p>>1];
        p >>= 1;
    }
    data[p] = val;
}

template <typename T>
T Heap<T>::poptop (void) {
    T res = data[1],
      tmp = data[size--];
    int p = 1,
        q = p << 1;
    if (data[q+1] < data[q])
        q++;
    while (q<=size && data[q]<tmp) {
        data[p] = data[q];
        p = q;
        q <<= 1;
        if (q+1<=size  &&  data[q+1] < data[q])
            q++;
    }
    data[p] = tmp;
    return res;
}

template <typename T>
T Heap<T>::gettop (void) {
    if (size==0) {
        return data[0];
    }
    return data[1];
}

template <typename T>
bool Heap<T>::empty (void) {
    return size == 0;
}

#endif