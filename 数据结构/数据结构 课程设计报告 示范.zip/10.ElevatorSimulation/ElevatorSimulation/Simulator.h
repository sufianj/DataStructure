#ifndef ANCHI_SIMULATOR_H
#define ANCHI_SIMULATOR_H

#include "CommonResource.h"

#include "Passenger.h"
#include "Elevator.h"
#include "Event.h"

const int MAX_SIM_TIME = 2000;
const int TICK_LENGTH = 100;

class Simulator {

public:
    void Start (void);

    void onTick (int currentTime);
    
    void onPsgEnterBuilding (PsgEvent* p);
    void onPsgStartWaiting  (PsgEvent* p);
    void onPsgStartQueuing  (PsgEvent* p);
    void onPsgGiveupWaiting (PsgEvent* p);
    void onPsgEnterElevator (PsgEvent* p);
    void onPsgLeaveBuilding (PsgEvent* p);

    void onEleWaitingGround (EleEvent* e);
    void onEleStatusChange  (EleEvent* e);
    void onEleOpenTheDoor   (EleEvent* e);
    void onElePassengersIO  (EleEvent* e);
    void onEleCloseTheDoor  (EleEvent* e);
    void onEleReadyToMove   (EleEvent* e);
    void onEleMoveUpstair   (EleEvent* e);
    void onEleMoveDownstair (EleEvent* e);
    void onEleStartWaiting  (EleEvent* e);

    void onCallController   (EleEvent* e);

private:
    ifstream _ipf;
    ofstream _opf;
    int _clockr;
    time_t _startTime;

    EleEvent Ele;

    Queue<Passenger> _PsgQueue[MAX_FLOOR];

    Heap<PsgEvent> _PsgEventQueue;
    Heap<EleEvent> _EleEventQueue;

    void tick (void);
    void windowUpdate (void);
};

#endif