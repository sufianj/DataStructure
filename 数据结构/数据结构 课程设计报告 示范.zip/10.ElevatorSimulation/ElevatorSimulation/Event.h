#ifndef ANCHI_EVENT_H
#define ANCHI_EVENT_H

#include "Elevator.h"
#include "Passenger.h"

//  ============================================================================================================
//  Level 1: Base of Events
//

class Event {
public:
    Event (void){};
    const string type (void);
    bool operator < (const Event obj) const;
    const int timer (void) const;
protected:
    int _timer;
    static const string _EventType;
};

//  ============================================================================================================
//  Level 2: Base of Passenger Events and Elevator Events 
//

//  Base of Passenger Events
class PsgEvent : public Event, public Passenger {
public:
    PsgEvent (void){}
    PsgEvent (int, const Passenger&);
};

//  Base of Elevator Events
class EleEvent : public Event, public Elevator {
public:
    EleEvent (void){}
    EleEvent (int, const Elevator&);
};

//  ============================================================================================================
//  Level 3: Actual Events
//

//  Passenger Events--------------------------------------------------------------------------------------------

//  Passenger Event 1: Passenger Enters Building
class PsgEnterBuilding : public PsgEvent {
public:
    PsgEnterBuilding(int, const Passenger&);
};

//  Passenger Event 2: Passenger Starts Waiting
class PsgStartWaiting : public PsgEvent {
public:
    PsgStartWaiting(int, const Passenger&);
};

//  Passenger Event 3: Passenger Starts Queuing
class PsgStartQueuing : public PsgEvent {
public:
    PsgStartQueuing(int, const Passenger&);
};

//  Passenger Event 4: Passenger Gives Up Waiting
class PsgGiveupWaiting : public PsgEvent {
public:
    PsgGiveupWaiting(int, const Passenger&);
};

//  Passenger Event 5: Passenger Enters Elevator
class PsgEnterElevator : public PsgEvent {
public:
    PsgEnterElevator(int, const Passenger&);
};

//  Passenger Event 6: Passenger Leaves Building
class PsgLeaveBuilding : public PsgEvent {
public:
    PsgLeaveBuilding(int, const Passenger&);
};

//  Elevator Events--------------------------------------------------------------------------------------------

//  Elevator Event 1: Elevator Buttom Pressed
class EleWaitingGround : public EleEvent {
public:
    EleWaitingGround(int, const Elevator&);
};

//  Elevator Event 2: Elevator Status Change
class EleStatusChange : public EleEvent {
public:
    EleStatusChange(int, const Elevator&);
};

//  Elevator Event 3: Elevator Opens the Door
class EleOpenTheDoor : public EleEvent {
public:
    EleOpenTheDoor(int, const Elevator&);
};

//  Elevator Event 4: Elevator Passengers I/O
class ElePassengersIO : public EleEvent {
public:
    ElePassengersIO(int, const Elevator&);
};

//  Elevator Event 5: Elevator Closes the Door
class EleCloseTheDoor : public EleEvent {
public:
    EleCloseTheDoor(int, const Elevator&);
};

//  Elevator Event 6: Elevator Ready to Move
class EleReadyToMove : public EleEvent {
public:
    EleReadyToMove(int, const Elevator&);
};

//  Elevator Event 7: Elevator Moves Upstair
class EleMoveUpstair : public EleEvent {
public:
    EleMoveUpstair(int, const Elevator&);
};

//  Elevator Event 8: Elevator Move Downstair
class EleMoveDownstair : public EleEvent {
public:
    EleMoveDownstair(int, const Elevator&);
};

//  Elevator Event 9: Elevator Starts Waiting
class EleStartWaiting : public EleEvent {
public:
    EleStartWaiting(int, const Elevator&);
};

#endif