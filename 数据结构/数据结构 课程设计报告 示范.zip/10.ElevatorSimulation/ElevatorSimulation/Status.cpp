#include "Status.h"

Status::Status (int floor, int state, bool openio, bool opennoio, bool longwait, int clockr) {
    this->_eleFloor = floor;
    this->_eleState = state;
    this->_eleOpenIO = openio;
    this->_eleOpenNoIO = opennoio;
    this->_eleLongWait = longwait;
    this->_clockr = clockr;
}

int Status::floor (void) {
    return this->_eleFloor;
}

int Status::state (void) {
    return this->_eleState;
}

bool Status::openIO (void) {
    return this->_eleOpenIO;
}

bool Status::openNoIO (void) {
    return this->_eleOpenNoIO;
}

int Status::clockr (void) {
    return this->_clockr;
}