#include "Event.h"

const string Event::_EventType = "";

const string Event::type (void) {
    return this->_EventType;
}

bool Event::operator < (const Event obj) const{
    return this->_timer < obj.timer();
}

const int Event::timer (void) const {
    return this->_timer;
}

PsgEvent::PsgEvent(int timer, const Passenger& psg) : Passenger(psg) {
    this->_timer = timer;
}

EleEvent::EleEvent(int timer, const Elevator& ele) : Elevator(ele) {
    this->_timer = timer;
}

PsgEnterBuilding::PsgEnterBuilding(int timer, const Passenger& psg) : PsgEvent(timer, psg){
}

PsgStartWaiting::PsgStartWaiting(int timer, const Passenger& psg) : PsgEvent(timer, psg){
}

PsgStartQueuing::PsgStartQueuing(int timer, const Passenger& psg) : PsgEvent(timer, psg){
}

PsgGiveupWaiting::PsgGiveupWaiting(int timer, const Passenger& psg) : PsgEvent(timer, psg){
}

PsgEnterElevator::PsgEnterElevator(int timer, const Passenger& psg) : PsgEvent(timer, psg){
}

PsgLeaveBuilding::PsgLeaveBuilding(int timer, const Passenger& psg) : PsgEvent(timer, psg){
}

EleWaitingGround::EleWaitingGround(int timer, const Elevator& ele) : EleEvent(timer, ele) {
}

EleStatusChange::EleStatusChange(int timer, const Elevator& ele) : EleEvent(timer, ele) {
}

EleOpenTheDoor::EleOpenTheDoor(int timer, const Elevator& ele) : EleEvent(timer, ele) {
}

ElePassengersIO::ElePassengersIO(int timer, const Elevator& ele) : EleEvent(timer, ele) {
}

EleCloseTheDoor::EleCloseTheDoor(int timer, const Elevator& ele) : EleEvent(timer, ele) {
}

EleReadyToMove::EleReadyToMove(int timer, const Elevator& ele) : EleEvent(timer, ele) {
}

EleMoveUpstair::EleMoveUpstair(int timer, const Elevator& ele) : EleEvent(timer, ele) {
}

EleMoveDownstair::EleMoveDownstair(int timer, const Elevator& ele) : EleEvent(timer, ele) {
}

EleStartWaiting::EleStartWaiting(int timer, const Elevator& ele) : EleEvent(timer, ele) {
}

const string PsgEnterBuilding::_EventType = "PsgEnterBuilding";
const string PsgStartWaiting::_EventType = "PsgStartWaiting";
const string PsgStartQueuing::_EventType = "PsgStartQueuing";
const string PsgGiveupWaiting::_EventType = "PsgGiveupWaiting";
const string PsgEnterElevator::_EventType = "PsgEnterElevator";
const string PsgLeaveBuilding::_EventType = "PsgLeaveBuilding";

const string EleWaitingGround::_EventType = "EleWaitingGround";
const string EleStatusChange::_EventType = "EleStatusChange";
const string EleOpenTheDoor::_EventType = "EleOpenTheDoor";
const string ElePassengersIO::_EventType = "ElePassengersIO";
const string EleCloseTheDoor::_EventType = "EleCloseTheDoor";
const string EleReadyToMove::_EventType = "EleReadyToMove";
const string EleMoveUpstair::_EventType = "EleMoveUpstair";
const string EleMoveDownstair::_EventType = "EleMoveDownstair";
const string EleStartWaiting::_EventType = "EleStartWaiting";