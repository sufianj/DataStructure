#ifndef ANCHI_STATUS_H
#define ANCHI_STATUS_H

class Status {
public:
    Status (void){}
    Status (int, int, bool, bool, bool, int);

    int floor();
    int state();
    bool openIO();
    bool openNoIO();
    bool longWait();
    int clockr();

private:
    int _eleFloor;
    int _eleState;
    bool _eleOpenIO;
    bool _eleLongWait;
    bool _eleOpenNoIO;
    int _clockr;
};

#endif