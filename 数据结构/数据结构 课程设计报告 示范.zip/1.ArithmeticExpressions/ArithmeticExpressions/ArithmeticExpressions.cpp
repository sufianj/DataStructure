/*
**      Arithmetic Expressions Calculation
**
**      Program by Anchi Bao
**      2010/12/30 
*/

#include "CommonResource.h"
#include "Stack.h"

//  ���������ŵ����ȼ���ϵ
char precede (char a, char b) {
    switch (a) {
        case '+':
        case '-':
            switch (b) {
                case '+':
                case '-':
                case ')':
                case '#':
                    return '>';
                default:
                    return '<';
            }
        case '*':
        case '/':
            if (b == '(')
                return '<';
            else
                return '>';
        case '(':
            if (b == ')')
                return '=';
            else
                return '<';
        case ')':
            return '>';
        case '#':
            if (b == '#')
                return '=';
            else
                return  '<';
    }
}

//  �ж�ĳ�ַ��Ƿ�Ϊ���
bool isoperator (const char c) {
    switch (c) {
        case '+': return true;
        case '-': return true;
        case '*': return true;
        case '/': return true;    
    }
    return false;
}

//  �ж�ĳ�ַ��Ƿ�Ϊ����
bool isnumber (const char c) {
    return c>='0' && c<='9';
}

//  �ж�ĳ�ַ��Ƿ�Ϊ����
bool isbracket (const char c) {
    return c=='(' || c==')';
}

//  �ж�ĳ�ַ��Ƿ�Ϊ�Ϸ��ַ�
bool legalchar (const char c) {
    if (isnumber(c))
        return true;
    switch (c) {
        case '+': return true;
        case '-': return true;
        case '*': return true;
        case '/': return true;
        case '(': return true;
        case ')': return true;
        case '#': return true;
    }
    return false;
}

//  �жϱ���ʽ�Ƿ�Ϸ�
bool illegal (const string expr) {
    int len = expr.length();
    if (expr[0]!='#' || expr[len-1]!='#') {
        cout << "Error: illegal start or head. " << endl;
        return true;
    }
    string::const_iterator iter;
    int cnt=0;
    for (iter=expr.begin(); iter!=expr.end(); iter++) {
        if (!legalchar(*iter)) {
            cout << "Error: illegal symble. " << endl;
            return true;
        }
        if (*iter == '(')
            cnt++;
        if (*iter == ')')
            cnt--;
        if (cnt < 0) {
            cout << "Error: illegal brackets. " << endl;
            return true;
        }
        if (isoperator(*iter) && isoperator(*(iter-1))) {
            cout << "Error: illegal operator. " << endl;
            return true;
        }
        if (isoperator(*iter) && *iter!='-' && !isnumber(*(iter-1)) && !isbracket(*(iter-1))) {
            cout << "Error: illegal operator. " << endl;
            return true;
        }
    }
    if (cnt != 0) {
        cout << "Error: illegal brackets. " << endl;
        return true;
    }
    cout << "Good!" << endl;
    return false;
}

//  ִ������
int operate (int a, char c, int b) {
    switch (c) {
        case '+': return a+b;
        case '-': return a-b;
        case '*': return a*b;
        case '/': return a/b;
    }
}

//  �����������ʽ
int calc (const string expr) {

    Stack<char> OPTR;   //  ���ջ
    Stack<int>  OPND;   //  ����ջ

    string::const_iterator iter = expr.begin();
    OPTR.push(*iter ++);

    int tmp;

    while (*iter!='#' || OPTR.get()!='#') {
        cout << "OPTR: "; OPTR.disp(cout);
        cout << "OPND: "; OPND.disp(cout);
        cout << "------------------" << endl;
        //  �����֣���OPNDջ
        if (isnumber(*iter)) {
            tmp = 0;
            do {
                tmp = tmp*10 + *iter - '0';
                iter++;
            } while ( isnumber(*iter) );
            OPND.push(tmp);
            continue;
        }
        //  ������� ��OPTRջ������Ƚϴ�С��ϵ
        switch (precede(OPTR.get(), *iter)) {
            //  С�ڹ�ϵ����OPTRջ
            case '<':
                OPTR.push(*iter);
                iter++;
                break;
            //  ���ڹ�ϵ��OPTRջ�������ջ
            case '=':
                OPTR.pop();
                iter++;
                break;
            //  ���ڹ�ϵ��ִ�����㣬�½����OPNDջ
            case '>':
                OPND.push( operate( OPND.pop(), OPTR.pop(), OPND.pop() ) );
                break;
        }
    }
    return OPND.pop();
}

int main () {
    string expr;

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    while (true) {
        //  �������ʽ������
        cin >> expr;
        cout << expr << endl;
        //  �����˳�ָ��
        if (expr == "exit")
            break;
        //  �кϷ���
        if (illegal(expr))
            continue;
        //  �Ϸ������㲢������
        cout << calc(expr) << endl;
    }
    return 0;
}