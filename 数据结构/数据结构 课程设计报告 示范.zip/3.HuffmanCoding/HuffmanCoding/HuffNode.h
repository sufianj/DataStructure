#ifndef ANCHI_HUFF_NODE_H
#define ANCHI_HUFF_NODE_H

#include "CommonResource.h"

class HuffNode {

private:
	char name;
	int count;
	string code;
	HuffNode *lc;
	HuffNode *rc;

public:

	HuffNode(){}
	HuffNode(char, int, HuffNode*, HuffNode*);
	
    const int amount();
	void setCode(const string code);
	const string getCode();
	const char getName();

	HuffNode* getLC();
	HuffNode* getRC();

	bool operator < (HuffNode obj);
	bool operator > (HuffNode obj);

	friend ostream & operator << (ostream &,HuffNode &);
	friend istream & operator >> (istream &,HuffNode &);
};

#endif