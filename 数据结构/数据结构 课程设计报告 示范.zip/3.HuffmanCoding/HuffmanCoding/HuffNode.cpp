#include "HuffNode.h"

HuffNode::HuffNode(char name, int count, HuffNode *lchild, HuffNode *rchild){
	this->name = name;
	this->count = count;
	this->lc = lchild;
	this->rc = rchild;
}

bool HuffNode::operator < (HuffNode obj){
	return this->count < obj.count;
}

bool HuffNode ::operator > (HuffNode obj){
	return (this->count) > (obj.count);
}

const int HuffNode::amount(){
	return count;
}

void HuffNode::setCode(const string code) {
	this->code = code;
}

const string HuffNode::getCode() {
	return this->code;
}

const char HuffNode::getName(){
	return this->name;
}

HuffNode* HuffNode::getLC() {
	return this->lc;
}

HuffNode* HuffNode::getRC() {
	return this->rc;
}

ostream & operator << (ostream & opt,HuffNode &obj) {
	opt << obj.name << " " << setw(5) << obj.count << " " << obj.code ;
	return opt;
}

istream & operator >> (istream & ipt, HuffNode &obj){
    int t;
    ipt.get();
    ipt.get(obj.name);
    ipt >> obj.count >> obj.code;
	return ipt;
}