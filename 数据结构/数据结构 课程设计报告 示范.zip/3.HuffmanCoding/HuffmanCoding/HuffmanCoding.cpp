/*
**      Huffman encoding & decoding
**
**      Program by Anchi Bao
**      2010/12/30 
*/


#include "CommonResource.h"
#include "HuffTree.h"

int main () {
	HuffTree HuffTest;
    
    cout << "Now encode input.txt to encode.txt..." << endl;
	HuffTest.encode("input.txt", "encode.txt");
    cout << endl
         << "Encode finished! " << endl << endl << endl;

    system("pause");
    cout << endl << endl;

    cout << "Now decode encode.txt to output.txt..." << endl;
    HuffTest.decode("encode.txt", "output.txt");
    cout << endl
         << "Decode finished! " << endl << endl << endl;
	
    system("pause");
	return 0;
}

