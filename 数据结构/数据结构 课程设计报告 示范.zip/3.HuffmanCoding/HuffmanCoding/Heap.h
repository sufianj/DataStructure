/*
**      Improved Binary Heap
**
**      Usage:
**              #include "HeapSort.h"
**              ...
**              Heap<int> intHeap(100);     //  Creates a heap which can store 100 integers.
**
**      Program by Anchi Bao
**      2010/12/15
*/

#ifndef ANCHI_HEAP_H
#define ANCHI_HEAP_H

template <typename T>
class Heap {

public:
    Heap (const int size);
    void insert (const T val);
    T poptop (void);
    bool empty (void);

private:
    T *data;
    int size;
};

template <typename T>
Heap<T>::Heap (const int size) {
data = new T [size+7];
    this->size = 0;
}

template <typename T>
bool Heap<T>::empty (void) {
    return size==0;
}

template <typename T>
void Heap<T>::insert (const T val) {
    int p = ++size;
    
    while (p > 1  &&  data[p>>1] > val) {
        data[p] = data[p>>1];
        p >>= 1;
    }
    data[p] = val;
}

template <typename T>
T Heap<T>::poptop (void) {
    T res = data[1],
      tmp = data[size--];
    int p = 1,
        q = p << 1;
    if (data[q+1] < data[q])
        q++;
    while (q<=size && data[q]<tmp) {
        data[p] = data[q];
        p = q;
        q <<= 1;
        if (q+1<=size  &&  data[q+1] < data[q])
            q++;
    }
    data[p] = tmp;
    return res;
}

#endif