#include "HuffTree.h"

HuffTree::HuffTree(void){
	data = new HuffNode[128*2];
	for (int i=0; i<256; i++)
		syblCnt[i] = 0;
	nodeCnt = 0;
}

void HuffTree::encode(const char *ipfName, const char* opfName){

	ifstream ipf(ipfName);
    ofstream opf(opfName);

    //  ����������ļ���ͳ�Ƹ��ַ����ִ���
	char temp;
	textsize = 0;
	while(true){
		ipf.get(temp);
        if (temp == '#')
            break;
		text[++textsize] = temp;
		syblCnt[temp]++;
	}
    //  Ϊ���ַ������ڵ�
	int i;
	for(i=0; i<128; i++) 
		data[i] = HuffNode(i, syblCnt[i], NULL, NULL);
	
    //  ���ڵ����С����
	nodeCnt = 128;
	Heap<HuffNode*> huffheap(128);
	for(i=0; i<128; i++)
		if(data[i].amount() != 0) 
			huffheap.insert(data+i);
	
    //  �������Ŷ�����
	HuffNode *p1, *p2;
	while(!huffheap.empty()){
		p1 = huffheap.poptop();
		if(huffheap.empty())
			break;
		p2 = huffheap.poptop(); 

		data[++nodeCnt] = HuffNode('\0', p1->amount() + p2->amount(), p1, p2);

		huffheap.insert(data+nodeCnt);
	}

    //  ���ɹ���������
	search(p1, "");

    //  ��������Ϣ������ļ�
    int cnt = 0;
    for (i=0; i<128; i++)
        if (data[i].amount() > 0)
            cnt++;

    opf << cnt << endl;

	for (i=0; i<128; i++)
		if (data[i].amount() > 0)
			opf << data[i] << endl;

    for (i=1; i<=textsize; i++)
        opf << data[ text[i] ].getCode();
    
    opf << endl << '#';

	ipf.close();
	opf.close();
}

void HuffTree::search(HuffNode *p, const string code) {
	if (p == NULL)
		return;
	p->setCode(code);
	search(p->getLC(), code+"0"); 
	search(p->getRC(), code+"1");
}

void HuffTree::decode(const char* ipfName, const char* opfName) {

	ifstream ipf(ipfName);
    ofstream opf(opfName);
	
	HuffNode HuffData[128];

    int i, cnt;

    HuffNode t;

    //  ���������Ϣ
    ipf >> cnt;
	for (i=0; i<cnt; i++) {
		ipf >> t;
        HuffData[t.getName()] = t;
    }

    //  ���������ı����������
    char c=' ';
	while (c!='0' && c!='1')
        ipf.get(c);
	string code;
	code.clear();
	code = code + c;
    while (c != '#') {

        for (i=0; i<128; i++) 
			if (code == HuffData[i].getCode()) {
				opf << HuffData[i].getName();
				code.clear();
                break;
			}

		ipf.get(c);
		code = code + c;
	}
    opf << '#';
    ipf.close();
    opf.close();
}
