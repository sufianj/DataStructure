/*
**      Critical Path - Directed Acyclic Graph
**      
**      Program by Anchi Bao
**      2010/12/30
*/

#include "CommonResource.h"
#include "Graph.h"

int main () {
    freopen("output.txt", "w", stdout);

    Graph G;
    ifstream ipf("input.txt");
    G.init(ipf);

    cout << "Critical Edges: " << endl << endl;
    G.CritPath(cout);

    cout << endl << endl;
    system("pause");

    return 0;
}