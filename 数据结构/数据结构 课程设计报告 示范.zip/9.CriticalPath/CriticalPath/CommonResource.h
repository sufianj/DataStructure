#ifndef ANCHI_COMMON_RESOURCE_H
#define ANCHI_COMMON_RESOURCE_H

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdio>

#include <cstdlib>
#include <cmath>
#include <cstring>

#include <string>
#include <memory>

#include <time.h>

#include "Queue.h"

#define INF 0x3fffffff

using namespace std;

#endif