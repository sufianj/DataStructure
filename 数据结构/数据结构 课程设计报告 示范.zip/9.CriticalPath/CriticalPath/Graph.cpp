#include "Graph.h"

void Graph::init (void) {
    memset(Mark, 0, sizeof(Mark));
    memset(Val, 0, sizeof(Val));
    memset(Map, 0, sizeof(Val));
    memset(inDegree, 0, sizeof(inDegree));
    memset(otDegree, 0, sizeof(otDegree));
    memset(TE, 0, sizeof(TE));
    memset(TL, 0, sizeof(TL));
    memset(TopoList, 0, sizeof(TopoList));
    N = E = TopoSize = 0;
}

void Graph::init (istream& ipt) {
    init();
    ipt >> N >> E;
    int i, s, t, v;
    for (i=1; i<=E; i++) {
        ipt >> s >> t >> v;
        Map[s][ ++otDegree[s] ] = t;
        Val[s][t] = v;
        inDegree[t] ++;
    }
}

void Graph::TopoSort (void) {
    Queue<int> Q;
    Q.push(1);
    int i, u, v;
    for (i=2; i<=N; i++)
        if (inDegree[i]==0)
            Q.push(i);
    while (!Q.empty()) {
        u = Q.pop();
        //cout << u << " " ;
        TopoList[++TopoSize] = u;
        for (i=1; i<=otDegree[u]; i++) {
            v = Map[u][i];
            inDegree[v]--;
            if (inDegree[v] == 0)
                Q.push(v);
        }
    }
    //cout << endl;
}

void slack(int &a, int b) {
    if (a < b)
        a = b;
}

void shrink(int &a, int b) {
    if (a > b)
        a = b;
}

void Graph::CritPath (ostream& opt) {
    TopoSort();

    int i, j, u, v;
    for (i=1; i<N; i++) {
        u = TopoList[i];
        for (j=1; j<=otDegree[u]; j++) {
            v = Map[u][j];
            slack(TE[v], TE[u] + Val[u][v]);
        }
    }
    for (i=1; i<=N; i++)
        TL[i] = TE[i];
    for (i=N-1; i>=1; i--) {
        u = TopoList[i];
        for (j=1; j<=otDegree[u]; j++) {
            v = Map[u][j];
            shrink(TL[u], TL[v] - Val[u][v]);
        }
    }

    for (u=1; u<=N; u++) {
        for (i=1; i<=otDegree[u]; i++) {
            v = Map[u][i];
            if (TE[u] == TL[v]-Val[u][v]) {
                Mark[u][v] = true;
                opt << u << "->" << v << ", val = " << Val[u][v] << endl;
            }
        }
    }
}