#include "Hash.h"

const int Hash::hash (const string str) {
    int hash = 1315423911; // nearly a prime - 1315423911 = 3 * 438474637
    string::const_iterator iter = str.begin();
    while (iter!=str.end()) {
        hash ^= ((hash << 5) + (*iter++) + (hash >> 2));
    }
    return (hash & 0x3FFFFFFF) % INIT_SHEET_SIZE;
}

void Hash::insert(const InfoNode p) {
    int di = 0,
        key = hash(p.GetTele());
	
    while (TeleSheet[key].used  == true) {
		key = (key + (++di)) % INIT_SHEET_SIZE;
	}
	TeleSheet[key].name = p.GetName();
	TeleSheet[key].tele = p.GetTele();
	TeleSheet[key].addr = p.GetAddr();
	TeleSheet[key].used = true;

    di = 0;
    key = hash(p.GetName());

    while (NameSheet[key].used  == true) {
		key = (key + (++di)) % INIT_SHEET_SIZE;
	}
	NameSheet[key].name = p.GetName();
	NameSheet[key].tele = p.GetTele();
	NameSheet[key].addr = p.GetAddr();
	NameSheet[key].used = true;
}

void Hash::lookup(const string t) {
    int di = 0,
        key = hash(t);

    SheetNode* Sheet;

    if (t[0]>='0' && t[0]<='9')
        Sheet = TeleSheet;
    else
        Sheet = NameSheet;

	while (Sheet[key].used  == true) {
		if(Sheet[key].tele!=t && Sheet[key].name!=t)
			key = (key + (++di)) % INIT_SHEET_SIZE;
		else {
			cout << "===============================================================" << endl;
			cout << "Record found! " << endl;
			cout << "---------------------------------------------------------------" << endl;
			cout << "Name:     " << Sheet[key].name << endl;
			cout << "Telephone " << Sheet[key].tele << endl;
			cout << "Address:  " << Sheet[key].addr << endl;
			cout << "===============================================================" << endl << endl << endl;
			system("pause");
			break;
		}
	}
	if(Sheet[key].used == false){
        cout << "===============================================================" << endl;
		cout << "Sorry, but the info requested does not exist. " << endl;
        cout << "===============================================================" << endl << endl << endl;
		system("pause");
	}
}