/*
**      Address Book - Hash Sheet
**      
**      An address book with hash features,
**      store Name, Telephone and Address,
**      lookup by Name of Telephone.
**
**      Program by Anchi Bao
**      2010/12/30
*/

#include "CommonResource.h"
#include "InfoNode.h"
#include "Hash.h"

int main(){

    ifstream ipf("addrbook.txt");
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
	
    int i;
	InfoNode Person[40];
	for (i=0; i<40; i++)
		Person[i].ReadInfo(ipf);

    Hash InfoSheet;
	for (i=0; i<40; i++)
        InfoSheet.insert(Person[i]); 

    string message;

	while (true) {
        cout << endl << endl;
		cout << "Please enter the phone number or person's name for quest, or 'exit' for quit."<< endl;
		cin >> message;
        cout << message << endl;
        if (message == "exit")
            break;
        InfoSheet.lookup(message);
	}

    system("pause");

	return 0;
}