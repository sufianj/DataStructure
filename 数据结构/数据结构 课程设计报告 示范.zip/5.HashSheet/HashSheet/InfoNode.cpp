#include "InfoNode.h"

InfoNode::InfoNode(void){
	name = "Unnamed";
	tele = "00000000000"; 
	addr = "No Address";
}

void InfoNode::ReadInfo(istream& ipt){
	ipt >> name >> tele >> addr;	
}

void InfoNode::PrintInfo(ostream& opt){
	opt << "===============================================================" << endl;
	opt << "Name:     " << name << endl;
	opt << "Telephone " << tele << endl;
	opt << "Address:  " << addr << endl;
	opt << "===============================================================" << endl;
}

const string InfoNode::GetName() const{
	return name;
}

const string InfoNode::GetTele() const{
	return tele;
}

const string InfoNode::GetAddr() const{
	return addr;
}