#ifndef ANCHI_HASH_H
#define ANCHI_HASH_H

#define INIT_SHEET_SIZE 1023

#include "CommonResource.h"
#include "InfoNode.h"

typedef struct SheetNode{
	string name;
	string tele;
	string addr;
	bool used;
    SheetNode(){
	    name = "Unnamed";
	    tele = "00000000000";
        addr = "No Address";
        used = false;
    }
};

class Hash {
public:
    void insert(const InfoNode p);
    void lookup(const string t);
private:
    const int hash (const string str);
    SheetNode TeleSheet[INIT_SHEET_SIZE];
    SheetNode NameSheet[INIT_SHEET_SIZE];
};

#endif