#ifndef ANCHI_INFO_NODE_H
#define ANCHI_INFO_NODE_H

#include "CommonResource.h"

class InfoNode{

public:
	InfoNode(void);

	void ReadInfo(istream&);
	void PrintInfo(ostream&);

	const string GetTele() const;
	const string GetName() const;
	const string GetAddr() const;

private:
	string name;
	string tele;
	string addr;
};

#endif

